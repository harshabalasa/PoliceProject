const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const app = express();
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({
  extended: true
}));

const apiKey = "9d99d0003cb7c1cfb3586c06ba2c4607";

const SapiKey = "ed7556381e0322993761ccfb3d1cffce";

app.use(express.static("public"));
mongoose.connect(
  "mongodb+srv://Harsha:Harsha@cluster0.f7r8m4f.mongodb.net/?retryWrites=true&w=majority"
);

//Mail API

const Mailjet = require("node-mailjet");

const mailjet = Mailjet.apiConnect(apiKey, SapiKey);

//Schemar

const officerSchema = new mongoose.Schema({
  _id: String,
  cadre: String,
  name: String,
  email: String,
  contact: String,
});

const commmissionSchema = new mongoose.Schema({
  _id: String,
  name: String,
  type: String,
});

const taskSchema = new mongoose.Schema({
  id1: String,
  id2: String,
  steps: Number,
  completedSteps: Number,
  commissionID: String,
  officerID: String,
  officerName: String,
  officerContact: String,
  officerCadre: String,
  commission: String,
  due: String,
  assigndate: String,
  completedDate: String,
  status: String,
});

const completedTaskSchema = new mongoose.Schema({
  commissionID: String,
  officerID: String,
  officerName: String,
  officerContact: String,
  officerCadre: String,
  commission: String,
  due: String,
  assigndate: String,
  completedDate: String,
  status: String,
});

//Models
const Officer = mongoose.model("Officer", officerSchema);
const Commission = mongoose.model("Commission", commmissionSchema);
const Task = mongoose.model("Task", taskSchema);
const CompletedTask = mongoose.model("CompletedTask", completedTaskSchema);

//home
app.get("/", (req, res) => {
  Task.find({})
    .sort({
      due: "ascending"
    })
    .exec((err, tasks) => {
      if (err) console.log(err);
      else {
        res.render("home", {
          tasks: tasks
        });
      }
    });

});
//assign
app.get("/assign", (req, res) => {
  Commission.find({}, (err, commissions) => {
    if (err) console.log(err);
    else {
      Officer.find({},(errr,officers)=>{
        if(errr){
          console.log(errr);
        }
        else {
          res.render("assign", {
            commissions: commissions,
            officers: officers
          });
        }
      })
    }
  });
});

app.post("/assign", (req, res) => {
  Officer.findOne({
    _id: req.body.officer
  }, (err, officer) => {
    Commission.findOne({
      _id: req.body.commission
    }, (err, commission) => {
      const newTask = {
        id1: req.body.id1,
        id2: req.body.id2,
        commissionID: req.body.commission,
        officerID: req.body.officer,
        commission: commission.name,
        steps: req.body.steps,
        completedSteps: 1,
        due: req.body.due,
        assigndate: req.body.assigning,
        officerName: officer.name,
        officerContact: officer.contact,
        officerCadre: officer.cadre,
        completedDate: "0000-00-00",
        status: "Completed",
      };


      Task.insertMany([newTask], (err) => {
        if (err) console.log(err);
        else res.redirect("/");
      });
    });
  });
});

//officer add

app.get("/officerAdd", (req, res) => {
  res.render("officeradd");
});

app.post("/officerAdd", (req, res) => {
  const newOfficer = {
    _id: req.body.id,
    cadre: req.body.cadre,
    name: req.body.name,
    email: req.body.email,
    contact: req.body.contact,
  };
  Officer.insertMany([newOfficer], (err) => {
    if (err) console.log(err);
  });
  res.redirect("/viewOfficer");
});

//officer view

app.get("/viewOfficer", (req, res) => {
  Officer.find({}, (err, data) => {
    res.render("viewofficer", {
      officers: data
    });
  });
});

//commission add
app.get("/commissionAdd", (req, res) => {
  res.render("commissionadd");
});
app.post("/commissionAdd", (req, res) => {
  const newCommission = {
    _id: req.body.id,
    name: req.body.name,
    type: req.body.type,
  };

  Commission.insertMany([newCommission], (err) => {
    if (err) console.log(err);
  });
  res.redirect("/viewCommission");
});

//commission view
app.get("/viewCommission", (req, res) => {
  Commission.find({}, (err, data) => {
      res.render("viewcommission", {
        commissions: data,
      });
  });
});

//officer delete
app.get("/delete/officer/:id", (req, res) => {
  const reqID = req.params.id;
  Officer.findOne({_id : reqID} , (err,officer)=>{
    if(err)console.log(err);
    else {
      Task.find({officerID : reqID} , (err , task)=>{
        if(err)console.log(err);
        else {
          if(task.length)res.sendStatus(403);
          else {
            Officer.findOneAndDelete({_id : reqID} , (err) =>{
              if(err)console.log(err);
            })
            res.redirect("/viewOfficer");
          }
        }
      })
    }
  })

});

//commission delete

app.get("/delete/commission/:id", (req, res) => {
  const reqID = req.params.id;
  console.log(reqID);

  Commission.deleteOne({
    _id: reqID
  }, (err) => {
    if (err) console.log(err);
  });

  res.redirect("/viewCommission");
});

//officer modify

app.get("/modify/officer/:id", (req, res) => {
  const reqID = req.params.id;

  Officer.find({
    _id: reqID
  }, (err, officer) => {
    if (!err) {
      res.render("officerModify", {
        officer: officer
      });
    }
  });
});

app.post("/modify/officer/:id", (req, res) => {
  const modifyOfficer = {
    _id: req.body.id,

    name: req.body.name,

    cadre: req.body.cadre,

    contact: req.body.contact,

    email: req.body.email,
  };

  if (modifyOfficer._id === req.params.id) {
    Officer.findOneAndUpdate({
        _id: req.params.id
      }, {
        $set: {
          name: modifyOfficer.name,

          cadre: modifyOfficer.cadre,

          email: modifyOfficer.email,

          contact: modifyOfficer.contact,
        },
      },
      (err) => {
        if (err) console.log(err);
        else res.redirect("/viewOfficer");
      }
    );
  } else {
    Officer.remove({
      _id: req.params.id
    }, (err) => {
      if (err) console.log(err);
    });

    Officer.insertMany([modifyOfficer], (err) => {
      if (err) console.log(err);
    });

    res.redirect("/viewOfficer");
  }
});

//task delete

app.get("/delete/pending/:id", (req, res) => {
  const reqID = req.params.id;
  Task.findOne({_id : reqID} , (err, task)=>{
    if(err)console.log(err)
    else {
      if(task.completedSteps === task.steps){
        //delete
        CompletedTask.insertMany([task],(err) => {
          if(err)console.log(err);
        })
        Task.findOneAndDelete({_id : task._id} , (err)=>{
          if(err)console.log(err)
        })
        res.redirect("/history");
      }
      else {
        task.completedSteps+=1;
        task.save();
        res.redirect("/")
      }
    }
  })
});

//history
app.get("/history", (req, res) => {
  CompletedTask.find({}, (err, compTasks) => {
    if (err) console.log(err);
    else {
      res.render("history", {
        compTasks: compTasks
      });
    }
  });
});

//clear history

app.get("/clearhistory", (req, res) => {
  CompletedTask.deleteMany({}, (err) => {
    if (err) console.log(err);
    else res.redirect("/history");
  });
});

app.listen(7000, () => {
  console.log("listening..");
});
